import React, {useState} from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';

const QuantityBtn = () => {
  return (
    <View>Quantity</View>
  );
};

export default QuantityBtn;